import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Play, Pause, ArrowRight, Video, Sparkles, Globe, Volume2, Layers, Music, Type } from "lucide-react";

export default function Hero() {
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeSegment, setActiveSegment] = useState(0);
  const [enableCaptions, setEnableCaptions] = useState(true);
  const [enableEffects, setEnableEffects] = useState(true);
  const [enableSoundWaves, setEnableSoundWaves] = useState(true);

  // Auto increment simulated clip progress
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setActiveSegment((prev) => (prev + 1) % 4);
    }, 4000);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const subtitles = [
    { text: "STOP SCROLLING 🚨", highlight: true },
    { text: "Here is why your videos get", highlight: false },
    { text: "ZERO RETENTION 📉", highlight: true },
    { text: "Let's fix it right now!", highlight: false },
  ];

  return (
    <section className="relative overflow-hidden pt-6 pb-16 lg:pt-8 lg:pb-20 bg-[#050505]">
      {/* Ambient background accent matching Bento Grid theme */}
      <div className="absolute top-1/4 right-10 w-96 h-96 bg-[#FFD000]/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-10 w-96 h-96 bg-indigo-950/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Main Bento Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          
          {/* Bento Card 1: Main Hero Pitch (Spans 2 cols, 2 rows equivalent) */}
          <div className="lg:col-span-2 bg-[#111] border border-white/10 rounded-[32px] p-8 sm:p-12 flex flex-col justify-center relative overflow-hidden group">
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#FFD000]/10 blur-[80px] rounded-full group-hover:bg-[#FFD000]/15 transition-all duration-500"></div>
            
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-900 border border-white/10 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-[0.2em] text-[#FFD000] mb-6 self-start">
              <Sparkles size={11} />
              <span>Short-Form Specialist</span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-6xl leading-[0.95] tracking-tighter mb-6 italic uppercase select-none text-white">
              High Retention <br />
              <span className="text-[#FFD000]">Reels</span> That Convert
            </h1>

            <p className="text-zinc-400 text-base sm:text-lg leading-relaxed max-w-md mb-8">
              Turning raw footages into viral gold for brands, coaches, and high-performance creators who demand pure relevance and visual perfection.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 items-stretch">
              <a
                href="https://www.instagram.com/editwitharman/"
                target="_blank"
                rel="noreferrer"
                className="group/btn inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#FFD000] hover:bg-amber-400 text-black font-black font-display text-xs uppercase tracking-wider rounded-full shadow-[0_4px_20px_rgba(255,208,0,0.2)] transition-all transform hover:-translate-y-0.5"
              >
                <span>Book Editing Trial</span>
                <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
              </a>
              <a
                href="#portfolio"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 border border-white/10 hover:border-white/20 bg-zinc-950/40 hover:bg-zinc-900 text-white font-black font-display text-xs uppercase tracking-wider rounded-full transition-all"
              >
                <span>View Portfolio</span>
              </a>
            </div>
          </div>

          {/* Bento Card 2: Interactive Video Phone Preview (Spans 1 col, 2 rows) */}
          <div className="lg:col-span-1 bg-[#1A1A1A] border border-white/10 rounded-[32px] p-6 flex flex-col justify-between items-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-0 opacity-60" />
            
            {/* Header info bar */}
            <div className="w-full relative z-10 flex justify-between items-center bg-black/60 backdrop-blur-md border border-white/10 px-3.5 py-2 rounded-2xl">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FFD000] animate-pulse" />
                <span className="text-[9px] uppercase font-mono font-black tracking-tight text-[#FFD000]">ACTIVE_PREVIEW.MP4</span>
              </div>
              <span className="text-[9px] font-mono text-zinc-500">0:15 / 0:60</span>
            </div>

            {/* Custom Interactive Screens Display */}
            <div className="relative w-full aspect-[9/16] bg-black/80 rounded-2xl border border-white/5 my-6 overflow-hidden flex flex-col justify-between p-4 pt-8">
              <div className="absolute inset-0 bg-gradient-to-b from-[#111]/30 via-transparent to-black/90 pointer-events-none" />
              
              {/* Captured Frame display */}
              <div className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none">
                <div className="w-24 h-24 rounded-full border border-white/10 flex items-center justify-center">
                  <Video size={36} className="text-[#FFD000]" />
                </div>
              </div>

              {/* Subtitle element display */}
              <div className="relative z-10 text-center px-1 my-auto select-none">
                {enableCaptions && (
                  <motion.div
                    key={activeSegment}
                    initial={{ scale: 0.85, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="inline-block"
                  >
                    <span
                      className={`text-lg font-display font-black tracking-tight uppercase block px-3 py-1.5 rounded-xl ${
                        subtitles[activeSegment].highlight
                          ? "bg-[#FFD000] text-black rotate-[-1deg] shadow-[0_4px_12px_rgba(255,208,0,0.3)] animate-pulse"
                          : "bg-black border border-white/10 text-white"
                      }`}
                    >
                      {subtitles[activeSegment].text}
                    </span>
                  </motion.div>
                )}
              </div>

              {/* Miniature audio waveforms */}
              <div className="relative z-10 space-y-1.5 bg-black/80 border border-white/10 p-2.5 rounded-xl">
                <div className="flex items-center gap-1.5">
                  <div className={`p-0.5 rounded bg-[#FFD000]/10 text-[#FFD000] ${enableSoundWaves ? 'opacity-100' : 'opacity-40'}`}>
                    <Music size={10} />
                  </div>
                  {/* Wave bars */}
                  <div className="flex-1 h-3 flex items-center justify-around gap-0.5 px-1">
                    {[...Array(12)].map((_, i) => (
                      <motion.div
                        key={i}
                        animate={
                          isPlaying && enableSoundWaves
                            ? { height: [3, Math.floor(Math.random() * 8) + 2, 3] }
                            : { height: 3 }
                        }
                        transition={{ repeat: Infinity, duration: 0.4 + i * 0.05, ease: "easeInOut" }}
                        className={`w-0.5 rounded-full ${enableSoundWaves ? "bg-[#FFD000]" : "bg-zinc-800"}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Simulated Phone Custom Dashboard Controls */}
            <div className="w-full relative z-10 flex gap-1.5 justify-between items-center bg-black/80 border border-white/10 p-1.5 rounded-full">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-2.5 bg-white hover:bg-neutral-200 text-black rounded-full transition-all duration-200"
              >
                {isPlaying ? <Pause size={10} fill="currentColor" /> : <Play size={10} fill="currentColor" />}
              </button>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setEnableCaptions(!enableCaptions)}
                  className={`text-[8px] font-mono px-2 py-1 rounded-md font-bold transition-all ${
                    enableCaptions ? "bg-[#FFD000] text-black" : "text-zinc-500 hover:text-white"
                  }`}
                >
                  CAPTIONS
                </button>
                <button
                  onClick={() => setEnableSoundWaves(!enableSoundWaves)}
                  className={`text-[8px] font-mono px-2 py-1 rounded-md font-bold transition-all ${
                    enableSoundWaves ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/20" : "text-zinc-500 hover:text-white"
                  }`}
                >
                  AUDIO
                </button>
              </div>
            </div>
          </div>

          {/* Bento Card 3: Stat Card 1 - total views (Spans 1 col, 1 row) */}
          <div className="bg-[#111] border border-white/10 rounded-[32px] p-8 flex flex-col justify-between group hover:border-[#FFD000]/30 transition-all duration-300">
            <div className="w-12 h-12 bg-zinc-900 border border-white/5 rounded-2xl flex items-center justify-center text-[#FFD000]">
              <Sparkles size={20} />
            </div>
            <div className="space-y-1 mt-6">
              <div className="text-4xl font-extrabold font-display text-[#FFD000] tracking-tighter">10M+</div>
              <p className="text-xs font-bold uppercase tracking-widest text-zinc-500">Collective Views Generated</p>
            </div>
          </div>

          {/* Bento Card 4: Stat Card 2 - years (Spans 1 col, 1 row) */}
          <div className="bg-[#FFD000] border border-[#FFD000] rounded-[32px] p-8 flex flex-col justify-between text-black group hover:bg-[#ffe045] transition-all duration-300">
            <div className="w-12 h-12 bg-black/5 rounded-2xl flex items-center justify-center text-black">
              <Video size={20} />
            </div>
            <div className="space-y-1 mt-6">
              <div className="text-4xl font-extrabold font-display tracking-tighter">3+ Years</div>
              <p className="text-xs font-black uppercase tracking-widest opacity-70">Editing Expertise</p>
            </div>
          </div>

          {/* Bento Card 5: Core Services Quick Glance (Spans 2 cols, 1 row) */}
          <div className="lg:col-span-2 bg-[#111] border border-white/10 rounded-[32px] p-8 flex flex-col justify-between group">
            <div className="flex justify-between items-center border-b border-white/5 pb-4 mb-4">
              <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-zinc-500">Core Services Spotlight</span>
              <span className="text-[9px] font-mono uppercase tracking-widest text-[#FFD000]">Active Systems</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <span className="text-xs font-black italic block uppercase text-white">01. Fast-Paced Cuts</span>
                <p className="text-[11px] text-zinc-500 leading-normal">Pacing designed to maximize consumer interest retention.</p>
              </div>
              <div className="space-y-1">
                <span className="text-xs font-black italic block uppercase text-white">02. Motion Captions</span>
                <p className="text-[11px] text-zinc-500 leading-normal">Perfect subtitle colors, timings, and dynamic layout overlays.</p>
              </div>
              <div className="space-y-1">
                <span className="text-xs font-black italic block uppercase text-white">03. Sound Design</span>
                <p className="text-[11px] text-zinc-500 leading-normal">High-fidelity ambient SFX accents that breathe lifelike energy.</p>
              </div>
              <div className="space-y-1">
                <span className="text-xs font-black italic block uppercase text-white">04. Color Grading</span>
                <p className="text-[11px] text-zinc-500 leading-normal">Bespoke palettes styled to make you stand out prominently.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
