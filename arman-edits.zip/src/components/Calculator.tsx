import { useState, useEffect } from "react";
import { Sliders, Check, Instagram, Copy, CheckSquare, Square, ThumbsUp } from "lucide-react";

export default function Calculator() {
  const [videoCount, setVideoCount] = useState(8);
  const [duration, setDuration] = useState("60s"); // "30s", "60s", "90s"
  const [needBroll, setNeedBroll] = useState(true);
  const [needHooks, setNeedHooks] = useState(false);
  const [needPriority, setNeedPriority] = useState(false);
  const [copied, setCopied] = useState(false);
  const [totalCost, setTotalCost] = useState(0);

  useEffect(() => {
    // Dynamic base pricing formula with bulk volume discounts
    let pricePerVideo = 135;
    if (videoCount >= 15) {
      pricePerVideo = 95; // High bulk discount
    } else if (videoCount >= 8) {
      pricePerVideo = 110; // Medium bulk discount
    } else if (videoCount >= 4) {
      pricePerVideo = 120;
    }

    let coreTotal = videoCount * pricePerVideo;

    // Adjust price by video duration
    if (duration === "30s") coreTotal *= 0.9; // 10% cheaper
    if (duration === "90s") coreTotal *= 1.25; // 25% more expensive

    // Add-on fees
    let addOnTotal = 0;
    if (needHooks) addOnTotal += videoCount * 12; // $12/video for scripts & hooks
    if (needBroll) addOnTotal += videoCount * 15; // $15/video for advanced visual lookup
    if (needPriority) addOnTotal += 150; // flat premium monthly speed-up

    setTotalCost(Math.round(coreTotal + addOnTotal));
  }, [videoCount, duration, needBroll, needHooks, needPriority]);

  const getTierName = () => {
    if (videoCount >= 16) return "Hyper-Growth Accelerator";
    if (videoCount >= 8) return "Consistent Creator Core";
    if (videoCount >= 4) return "Brand Starter Pack";
    return "Custom Testing Gear";
  };

  const generateQuoteText = () => {
    const addons = [];
    if (needHooks) addons.push("Hook/Script Strategy");
    if (needBroll) addons.push("B-Roll Overlays");
    if (needPriority) addons.push("24h priority speedup");
    const addonStr = addons.length > 0 ? ` + [${addons.join(", ")}]` : "";
    return `Hey Arman! I used your quote calculator and want a "${getTierName()}" package: ${videoCount} videos (${duration} length) per month${addonStr}. Let's discuss pricing!`;
  };

  const handleCopyQuote = () => {
    navigator.clipboard.writeText(generateQuoteText());
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="calculator" className="py-20 border-t border-white/5 bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Heading */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-[0.2em] text-[#FFD000]">
            <span>Calculator</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl tracking-tighter text-white leading-[0.95] italic uppercase select-none">
            Interactive <span className="text-[#FFD000]">Package</span> Builder
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed max-w-2xl pt-2">
            Drag the parameters to generate a fully customized monthly scope matching your brand volume, select individual quality add-ons, and review your custom estimate.
          </p>
        </div>

        {/* Calculator Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Controls Form Grid */}
          <div className="lg:col-span-12 xl:col-span-7 bg-[#111] border border-white/10 rounded-[32px] p-6 sm:p-8 space-y-8 flex flex-col justify-between">
            
            {/* Slider count */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="text-xs font-black uppercase tracking-[0.2em] text-zinc-400">
                  Monthly Video Quantity
                </label>
                <div className="px-3 py-1 bg-[#FFD000]/10 border border-[#FFD000]/30 rounded-xl">
                  <span className="font-mono text-xl font-black text-[#FFD000]">{videoCount}</span>
                  <span className="text-[9px] text-[#FFD000]/80 uppercase font-black ml-1.5">Videos</span>
                </div>
              </div>

              <input
                type="range"
                min="1"
                max="30"
                value={videoCount}
                onChange={(e) => setVideoCount(parseInt(e.target.value))}
                className="w-full h-1.5 bg-zinc-850 rounded-lg appearance-none cursor-pointer accent-[#FFD000]"
              />
              
              <div className="flex justify-between text-[10px] font-mono text-zinc-600 uppercase font-black tracking-wider">
                <span>1 Video</span>
                <span>8 (Core)</span>
                <span>15 (Growth)</span>
                <span>30 (Max)</span>
              </div>
            </div>

            {/* Video Duration */}
            <div className="space-y-4">
              <label className="text-xs font-black uppercase tracking-[0.2em] text-zinc-400 block">
                Average Video Duration
              </label>
              
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: "30s", title: "Under 30s", subtitle: "Quick Edits" },
                  { id: "60s", title: "Under 60s", subtitle: "Retention Core" },
                  { id: "90s", title: "Under 90s", subtitle: "Expanded Cuts" },
                ].map((d) => (
                  <button
                    key={d.id}
                    onClick={() => setDuration(d.id)}
                    className={`p-4 rounded-[18px] border text-left transition-all duration-300 ${
                      duration === d.id
                        ? "bg-[#FFD000]/10 border-[#FFD000] text-white shadow-inner"
                        : "bg-zinc-950 border-white/5 text-zinc-400 hover:border-white/10 hover:bg-zinc-900/40"
                    }`}
                  >
                    <div className="text-[10px] font-mono text-zinc-500 mb-0.5 uppercase tracking-wider">{d.subtitle}</div>
                    <strong className="text-xs sm:text-sm font-black uppercase tracking-tight block">{d.title}</strong>
                  </button>
                ))}
              </div>
            </div>

            {/* Add-ons Checklist */}
            <div className="space-y-4">
              <label className="text-xs font-black uppercase tracking-[0.2em] text-zinc-400 block">
                Additional Creative Layers
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Hook Strategy addon */}
                <button
                  onClick={() => setNeedHooks(!needHooks)}
                  className={`p-4 rounded-[18px] border text-left transition-all duration-350 flex items-center justify-between gap-4 ${
                    needHooks
                      ? "bg-zinc-900 border-[#FFD000]/40 text-white"
                      : "bg-zinc-950 border-white/5 text-zinc-400 hover:border-white/10 hover:bg-zinc-900/40"
                  }`}
                >
                  <div className="space-y-0.5">
                    <strong className="text-xs sm:text-sm font-black uppercase tracking-tight block">Scripting & Hook Consult</strong>
                    <span className="text-[10px] text-zinc-500">+$12/video (Structure Advice)</span>
                  </div>
                  {needHooks ? (
                    <CheckSquare size={16} className="text-[#FFD000] flex-shrink-0" />
                  ) : (
                    <Square size={16} className="text-zinc-700 flex-shrink-0" />
                  )}
                </button>

                {/* B-Roll Lookup */}
                <button
                  onClick={() => setNeedBroll(!needBroll)}
                  className={`p-4 rounded-[18px] border text-left transition-all duration-350 flex items-center justify-between gap-4 ${
                    needBroll
                      ? "bg-zinc-900 border-[#FFD000]/40 text-white"
                      : "bg-zinc-950 border-white/5 text-zinc-400 hover:border-white/10 hover:bg-zinc-900/40"
                  }`}
                >
                  <div className="space-y-0.5">
                    <strong className="text-xs sm:text-sm font-black uppercase tracking-tight block">Cinema B-Roll Sourcing</strong>
                    <span className="text-[10px] text-zinc-500">+$15/video (Premium clips)</span>
                  </div>
                  {needBroll ? (
                    <CheckSquare size={16} className="text-[#FFD000] flex-shrink-0" />
                  ) : (
                    <Square size={16} className="text-zinc-700 flex-shrink-0" />
                  )}
                </button>

                {/* Speed-up Delivery */}
                <button
                  onClick={() => setNeedPriority(!needPriority)}
                  className={`p-4 rounded-[18px] border text-left transition-all duration-350 flex items-center justify-between gap-4 sm:col-span-2 ${
                    needPriority
                      ? "bg-zinc-900 border-[#FFD000]/40 text-white"
                      : "bg-zinc-950 border-white/5 text-zinc-400 hover:border-white/10 hover:bg-zinc-900/40"
                  }`}
                >
                  <div className="space-y-0.5">
                    <strong className="text-xs sm:text-sm font-black uppercase tracking-tight block">24h Priority Turnaround Speed</strong>
                    <span className="text-[10px] text-zinc-500">+$150/month (Fast-track monthly pipeline)</span>
                  </div>
                  {needPriority ? (
                    <CheckSquare size={16} className="text-[#FFD000] flex-shrink-0" />
                  ) : (
                    <Square size={16} className="text-zinc-700 flex-shrink-0" />
                  )}
                </button>
              </div>
            </div>

          </div>

          {/* Price Output Display Card */}
          <div className="lg:col-span-12 xl:col-span-5 bg-[#1A1A1A] border border-white/10 rounded-[32px] p-8 flex flex-col justify-between relative overflow-hidden">
            {/* Visual glow element */}
            <div className="absolute top-0 right-0 w-44 h-44 bg-[#FFD000]/5 rounded-full blur-[80px]" />

            {/* Price Output Title */}
            <div className="space-y-2 relative z-10">
              <div className="inline-flex items-center gap-1 bg-[#FFD000]/10 border border-[#FFD000]/20 text-[10px] font-mono font-black uppercase tracking-widest px-2.5 py-1 rounded-full text-[#FFD000]">
                <ThumbsUp size={10} />
                <span>Recommended Tier</span>
              </div>
              <h3 className="font-display font-black text-2xl text-white italic uppercase tracking-tight pt-2">
                {getTierName()}
              </h3>
              <p className="text-zinc-400 text-xs sm:text-sm">
                Perfect scope for maintaining solid engagement and generating brand authority continuously.
              </p>
            </div>

            {/* Price block */}
            <div className="my-10 space-y-1 relative z-10">
              <div className="text-[9px] font-mono uppercase font-black tracking-widest text-[#FFD000]">
                Estimated Monthly Value
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-5xl sm:text-6xl font-black text-[#FFD000] tracking-tighter">
                  ${totalCost.toLocaleString()}
                </span>
                <span className="text-zinc-500 font-mono text-xs uppercase font-bold">/ month</span>
              </div>
              <p className="text-[10px] font-mono text-zinc-500 uppercase font-black tracking-wider">
                Average rate: ~${Math.round(totalCost / videoCount)} per fully retention-styled video.
              </p>
            </div>

            {/* Checklist highlights */}
            <div className="space-y-3 border-t border-white/5 pt-6 mb-8 relative z-10">
              <div className="flex items-center gap-2.5 text-zinc-300 text-xs sm:text-sm">
                <Check className="text-[#FFD000] shrink-0" size={14} />
                <span>Custom Brand Typography Styling</span>
              </div>
              <div className="flex items-center gap-2.5 text-zinc-300 text-xs sm:text-sm">
                <Check className="text-[#FFD000] shrink-0" size={14} />
                <span>Sound Effects (SFX) Track Included</span>
              </div>
              <div className="flex items-center gap-2.5 text-zinc-300 text-xs sm:text-sm">
                <Check className="text-[#FFD000] shrink-0" size={14} />
                <span>Fully Licensed Visual Asset Sourcing</span>
              </div>
            </div>

            {/* Quote actions */}
            <div className="space-y-3 relative z-10">
              <button
                onClick={handleCopyQuote}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 bg-zinc-900 border border-white/5 text-white font-black uppercase tracking-wider text-xs rounded-full transition-all duration-200 active:scale-95"
              >
                <Copy size={14} />
                <span>{copied ? "Copied Proposal!" : "Copy Package Proposal"}</span>
              </button>

              <a
                href={`https://www.instagram.com/editwitharman/`}
                target="_blank"
                rel="noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 bg-[#FFD000] hover:bg-amber-400 text-black font-black uppercase tracking-wider text-xs rounded-full transition-all duration-200 shadow-[0_4px_16px_rgba(255,208,0,0.15)] active:scale-95"
              >
                <Instagram size={14} />
                <span>DM Request to Arman</span>
              </a>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
