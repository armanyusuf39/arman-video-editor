import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PORTFOLIO_ITEMS } from "../data";
import { Play, Pause, RotateCcw, Sparkles, CheckCircle2, Clock, Smartphone, Volume2, VolumeX } from "lucide-react";

export default function Portfolio() {
  const [selectedItem, setSelectedItem] = useState(PORTFOLIO_ITEMS[0]);
  const [isPlaying, setIsPlaying] = useState(true);
  const [captionIndex, setCaptionIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  // Subtitle progression simulation
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setCaptionIndex((prev) => (prev + 1) % selectedItem.captions.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [isPlaying, selectedItem]);

  // Reset caption index when switching project tabs
  const handleSelectProject = (project: typeof PORTFOLIO_ITEMS[0]) => {
    setSelectedItem(project);
    setCaptionIndex(0);
    setIsPlaying(true);
  };

  return (
    <section id="portfolio" className="py-20 border-t border-white/5 bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-[0.2em] text-[#FFD000]">
            <span>Portfolio Cases</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl tracking-tighter text-white leading-[0.95] italic uppercase select-none">
            Featured <span className="text-[#FFD000]">Editing</span> Showcase
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed max-w-2xl pt-2">
            Take a look at how I format client short-form reels for high retention. Click a style below to view its simulated editing layer, subtitles flow, and production timeline.
          </p>
        </div>

        {/* Outer Shell Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Project List / Sidebar (Tabs) */}
          <div className="lg:col-span-5 space-y-4 order-2 lg:order-1">
            <h3 className="text-[10px] uppercase font-mono font-black tracking-[0.2em] text-zinc-500 mb-2 px-1">
              Select Live Sample
            </h3>
            
            <div className="flex flex-col gap-3">
              {PORTFOLIO_ITEMS.map((item) => {
                const isActive = item.id === selectedItem.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectProject(item)}
                    className={`w-full text-left p-6 rounded-[24px] border transition-all duration-300 relative overflow-hidden flex flex-col gap-1.5 ${
                      isActive
                        ? "bg-[#111] border-[#FFD000] shadow-[0_4px_24px_rgba(255,208,0,0.05)]"
                        : "bg-[#111]/40 border-white/5 hover:border-white/10 hover:bg-[#111]/70"
                    }`}
                  >
                    {isActive && (
                      <div className="absolute right-6 top-6 w-2 h-2 rounded-full bg-[#FFD000] animate-pulse" />
                    )}
                    <span className={`text-[9px] font-mono uppercase tracking-widest ${isActive ? 'text-[#FFD000]' : 'text-zinc-500'}`}>
                      {item.category}
                    </span>
                    <strong className="font-display font-black text-lg text-white italic uppercase tracking-tight">
                      {item.title}
                    </strong>
                    <p className={`text-xs leading-relaxed ${isActive ? 'text-zinc-300' : 'text-zinc-500'}`}>
                      {item.description}
                    </p>
                    <div className="flex items-center gap-2 mt-2 font-mono text-[10px] text-[#FFD000] uppercase font-black">
                      <Clock size={11} />
                      <span>Duration: {item.duration}s</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Direct Value Message Widget */}
            <div className="bg-[#111] border border-white/10 p-6 rounded-[24px] space-y-3">
              <div className="flex items-center gap-2.5 text-zinc-300">
                <CheckCircle2 className="text-[#FFD000] flex-shrink-0" size={16} />
                <span className="text-xs font-black uppercase tracking-wider text-white">Retention Guarantee Included</span>
              </div>
              <p className="text-xs text-zinc-500 leading-relaxed">
                All portfolios incorporate the complete engagement stack: high-quality subtitles, micro-zooms, appropriate emojis, custom B-roll integration, and high-tempo sound cues.
              </p>
            </div>
          </div>

          {/* Interactive Player Screen (Right Side Preview) */}
          <div className="lg:col-span-7 flex flex-col justify-center items-center order-1 lg:order-2">
            <div className="w-full max-w-[340px] bg-[#111] rounded-[36px] p-4 border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.8)] relative">
              
              {/* Phone Speaker Notch */}
              <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-24 h-4 bg-zinc-950 rounded-full z-20 flex items-center justify-center border border-white/5">
                <span className="w-8 h-1 bg-zinc-900 rounded-full" />
              </div>

              {/* Workspace Container */}
              <div className="relative rounded-[28px] overflow-hidden bg-neutral-950 aspect-[9/16] border border-white/5 flex flex-col justify-between p-4 pt-10">
                {/* Overlay color background based on tab */}
                <div className={`absolute inset-0 bg-gradient-to-b ${selectedItem.bgColor} z-0 opacity-100 transition-all duration-500`} />

                {/* Video elements indicator */}
                <div className="absolute inset-0 flex flex-col items-center justify-center opacity-40 z-0">
                  <Smartphone className="text-white/5 animate-pulse" size={160} />
                </div>

                {/* Top metadata tags */}
                <div className="relative z-10 flex justify-between items-center bg-black/45 backdrop-blur-sm border border-white/5 px-3 py-1.5 rounded-full text-white">
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FFD000] animate-pulse" />
                    <span className="text-[9px] uppercase font-mono font-bold tracking-tight">ACTIVE_PREVIEW.mp4</span>
                  </div>
                  <div className="text-[9px] font-mono text-zinc-400">
                    {captionIndex + 1} / {selectedItem.captions.length} Clips
                  </div>
                </div>

                {/* Animated captions showcase panel */}
                <div className="relative z-10 text-center px-4 my-auto select-none">
                  <AnimatePresence mode="wait">
                    {isPlaying && (
                      <motion.div
                        key={`${selectedItem.id}-${captionIndex}`}
                        initial={{ opacity: 0, scale: 0.8, y: 15 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: -10 }}
                        transition={{ duration: 0.18, ease: "easeOut" }}
                        className="inline-block"
                      >
                        <span
                          className={`text-lg font-display font-black tracking-tighter uppercase px-3.5 py-2 rounded-xl block ${
                            selectedItem.captions[captionIndex]?.highlight
                              ? "bg-[#FFD000] text-black scale-105 rotate-[-2deg] shadow-[0_8px_20px_rgba(255,208,0,0.4)]"
                              : "bg-black border border-white/10 text-white"
                          }`}
                        >
                          {selectedItem.captions[captionIndex]?.text}
                        </span>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {!isPlaying && (
                    <div className="text-zinc-500 font-mono text-xs animate-pulse">
                      PAUSED AT FRAME {captionIndex}
                    </div>
                  )}
                </div>

                {/* Audio waveforms & timeline feedback visualization */}
                <div className="relative z-10 space-y-3 bg-black/70 backdrop-blur-md border border-white/5 p-3 rounded-2xl">
                  
                  {/* Hook preview bar */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[8px] font-mono text-[#FFD000] font-black uppercase tracking-wider bg-[#FFD000]/10 border border-[#FFD000]/20 px-1.5 py-0.5 rounded-sm">
                      HOOK
                    </span>
                    <marquee className="text-[10px] font-mono text-white/90 select-none">
                      {selectedItem.hookText}
                    </marquee>
                  </div>

                  {/* Playback timeline tracker */}
                  <div className="h-1 bg-zinc-800 rounded-full overflow-hidden relative">
                    <motion.div
                      className="absolute left-0 top-0 bottom-0 bg-[#FFD000]"
                      animate={isPlaying ? { width: ["0%", "100%"] } : {}}
                      transition={
                        isPlaying
                          ? { repeat: Infinity, duration: selectedItem.captions.length * 2, ease: "linear" }
                          : { duration: 0 }
                      }
                    />
                  </div>

                  {/* Operational controls */}
                  <div className="flex justify-between items-center">
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="p-2 bg-white hover:bg-neutral-250 text-black rounded-full transition-all active:scale-95 duration-100"
                        title={isPlaying ? "Pause" : "Play"}
                      >
                        {isPlaying ? <Pause size={10} fill="currentColor" /> : <Play size={10} fill="currentColor" />}
                      </button>
                      <button
                        onClick={() => setCaptionIndex(0)}
                        className="p-2 bg-zinc-900 border border-white/5 text-zinc-300 rounded-full hover:text-white transition-all active:scale-95"
                        title="Restart Loop"
                      >
                        <RotateCcw size={10} />
                      </button>
                    </div>

                    {/* Mute Toggle Simulation */}
                    <button
                      onClick={() => setIsMuted(!isMuted)}
                      className="p-2 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                    >
                      {isMuted ? <VolumeX size={12} /> : <Volume2 size={12} />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Phone Screen bottom bar */}
              <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-zinc-800 rounded-full" />
            </div>

            {/* Note prompt under mock */}
            <p className="mt-4 text-[10px] font-mono text-zinc-600 tracking-widest flex items-center gap-1.5">
              <Sparkles size={11} className="text-[#FFD000] animate-pulse" />
              <span>TAP PLAYER CONTROLS TO PREVIEW EFFECTS</span>
            </p>
          </div>

        </div>
      </div>
    </section>
  );
}
