import { Instagram, ArrowUpRight, MessageSquare, ShieldCheck, Mail, Sparkles } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer id="footer" className="relative overflow-hidden bg-[#050505] border-t border-white/5">
      
      {/* Decorative ambient spot */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#FFD000]/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Conversion Booster / Lead Banner (CTA Section) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10 text-center space-y-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#FFD000]/10 border border-[#FFD000]/20 text-[10px] font-mono font-black uppercase tracking-widest text-[#FFD000] rounded-full">
          <Sparkles size={11} fill="currentColor" />
          <span>Launch Your Growth</span>
        </div>

        <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl tracking-tighter text-white max-w-4xl mx-auto leading-[0.95] italic uppercase select-none">
          Ready to make your raw footage look <span className="text-[#FFD000]">completely professional?</span>
        </h2>
        
        <p className="text-zinc-450 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed pt-2">
          Send me your raw concepts and clips. I’ll structure the hooks, write kinetic subtitlers, find premium B-rolls, and hand back ready-to-post vertical edits targeted for high retention.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="https://www.instagram.com/editwitharman/"
            target="_blank"
            rel="noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4.5 bg-[#FFD000] hover:bg-amber-400 text-black font-black uppercase tracking-wider text-xs rounded-full shadow-[0_4px_24px_rgba(255,208,0,0.15)] transition-all active:scale-95 duration-150"
          >
            <Instagram size={18} />
            <span className="font-display">DM "EDIT" on Instagram</span>
            <ArrowUpRight size={14} className="opacity-80" />
          </a>
          
          <a
            href="mailto:armanusuf2018@gmail.com"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4.5 border border-white/10 hover:border-white/20 bg-zinc-950 text-white font-black uppercase tracking-wider text-xs rounded-full transition-colors font-sans"
          >
            <Mail size={16} />
            <span>armanusuf2018@gmail.com</span>
          </a>
        </div>

        {/* Confidence highlights */}
        <div className="flex flex-wrap justify-center items-center gap-x-8 gap-y-3 pt-6 text-xs text-zinc-500 font-mono">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="text-[#FFD000]" size={14} />
            <span>Secure 48h turnaround</span>
          </span>
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="text-[#FFD000]" size={14} />
            <span>Dedicated Slack channel</span>
          </span>
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="text-[#FFD000]" size={14} />
            <span>100% satisfaction check</span>
          </span>
        </div>
      </div>

      {/* Sub-Footer Copyright credits bar */}
      <div className="border-t border-white/5 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-zinc-500 text-center sm:text-left">
          <div>
            © {currentYear} Arman Yusuf — Short-Form Video Editor. All rights reserved.
          </div>
          <div className="flex gap-4">
            <a href="https://www.instagram.com/editwitharman/" target="_blank" rel="noreferrer" className="hover:text-[#FFD000] transition-colors">
              @editwitharman
            </a>
            <span>•</span>
            <span className="text-zinc-650">Professional React Framework</span>
          </div>
        </div>
      </div>

    </footer>
  );
}
