import { PACKAGES } from "../data";
import { Check, ArrowRight, Star } from "lucide-react";

export default function Pricing() {
  return (
    <section id="pricing" className="py-20 border-t border-white/5 bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-[0.2em] text-[#FFD000]">
            <span>Partnership Plans</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl tracking-tighter text-white leading-[0.95] italic uppercase select-none">
            Predictable <span className="text-[#FFD000]">Retainer</span> Packages
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed max-w-2xl pt-2">
            Start with a test reel to verify speed and styling, or secure a regular weekly slot to build systemic organic growth.
          </p>
        </div>

        {/* Pricing Layout Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
          {PACKAGES.map((pkg) => (
            <div
              key={pkg.id}
              className={`group flex flex-col justify-between rounded-[32px] p-8 relative transition-all duration-300 ${
                pkg.popular
                  ? "bg-[#1A1A1A] border-2 border-[#FFD000] shadow-[0_10px_35px_rgba(255,208,0,0.1)] z-10 scale-[1.01]"
                  : "bg-[#111] hover:bg-[#1A1A1A] border border-white/10"
              }`}
            >
              {/* Highlight ribbon / tag on card */}
              {pkg.popular && (
                <div className="absolute top-6 right-6 inline-flex items-center gap-1 bg-[#FFD000] text-black text-[10px] font-mono font-black uppercase tracking-widest px-3 py-1 rounded-full">
                  <Star size={10} fill="currentColor" />
                  <span>Most Popular</span>
                </div>
              )}

              <div>
                {/* Meta details */}
                <div className="space-y-1 mb-6">
                  <span className="text-zinc-500 font-mono text-[10px] uppercase tracking-widest font-black">
                    {pkg.id === "single" ? "Starter Tier" : "Retainer Tier"}
                  </span>
                  <h3 className="font-display font-black text-2xl text-white italic uppercase tracking-tight">
                    {pkg.title}
                  </h3>
                  <p className="text-zinc-400 text-xs sm:text-sm leading-relaxed pt-1">
                    {pkg.description}
                  </p>
                </div>

                {/* Price tag */}
                <div className="flex items-baseline gap-1 bg-zinc-950 border border-white/5 rounded-2xl p-4 mb-8">
                  <span className="font-mono text-4xl sm:text-5xl font-black text-white group-hover:text-[#FFD000] transition-colors tracking-tight">
                    {pkg.price}
                  </span>
                  {pkg.id !== "single" && (
                    <span className="text-zinc-500 text-xs font-mono uppercase font-bold pl-1">/ month</span>
                  )}
                </div>

                {/* Features List */}
                <div className="space-y-4 mb-8">
                  <div className="text-[10px] font-mono font-black text-zinc-550 uppercase tracking-widest">
                    Included Deliverables:
                  </div>
                  <ul className="space-y-3 font-sans" style={{ gridGap: 0, margin: 0, listStyle: "none" }}>
                    {pkg.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-zinc-300 text-xs sm:text-sm" style={{ padding: 0 }}>
                        <div className="mt-0.5 rounded-full p-0.5 bg-[#FFD000]/10 border border-[#FFD000]/25">
                          <Check className="text-[#FFD000] shrink-0" size={12} />
                        </div>
                        <span className="leading-tight">{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Call to Active Button */}
              <div className="pt-6 border-t border-white/5 mt-auto">
                <a
                  href="https://www.instagram.com/editwitharman/"
                  target="_blank"
                  rel="noreferrer"
                  className={`w-full inline-flex items-center justify-center gap-2 px-6 py-4 font-display font-black uppercase tracking-wider text-xs rounded-full transition-all duration-200 active:scale-95 ${
                    pkg.popular
                      ? "bg-[#FFD000] hover:bg-amber-400 text-black shadow-[0_4px_16px_rgba(255,208,0,0.15)]"
                      : "bg-zinc-900 border border-white/5 text-white hover:bg-zinc-805"
                  }`}
                >
                  <span>{pkg.ctaText}</span>
                  <ArrowRight size={14} />
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
