import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, ArrowUpRight, Instagram } from "lucide-react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      id="main-nav"
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-[#050505]/95 backdrop-blur-md border-b border-white/5 shadow-lg"
          : "bg-transparent border-b border-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex-shrink-0">
            <a href="#" className="flex items-center space-x-2">
              <span className="font-display font-black text-2xl tracking-tighter text-white uppercase italic">
                Arman<span className="text-[#FFD000]">Edits</span>
              </span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a
              href="#services"
              className="text-zinc-400 hover:text-[#FFD000] font-black uppercase text-xs tracking-wider transition-colors"
            >
              Services
            </a>
            <a
              href="#portfolio"
              className="text-zinc-400 hover:text-[#FFD000] font-black uppercase text-xs tracking-wider transition-colors"
            >
              Portfolio
            </a>
            <a
              href="#process"
              className="text-zinc-400 hover:text-[#FFD000] font-black uppercase text-xs tracking-wider transition-colors"
            >
              Process
            </a>
            <a
              href="#calculator"
              className="text-zinc-400 hover:text-[#FFD000] font-black uppercase text-xs tracking-wider transition-colors"
            >
              Calculator
            </a>
            <a
              href="#pricing"
              className="text-zinc-400 hover:text-[#FFD000] font-black uppercase text-xs tracking-wider transition-colors"
            >
              Packages
            </a>
          </nav>

          {/* Desktop Call to Action */}
          <div className="hidden md:flex items-center">
            <a
              href="https://www.instagram.com/editwitharman/"
              target="_blank"
              rel="noreferrer"
              className="group relative inline-flex items-center justify-center gap-2 bg-[#FFD000] text-black font-black uppercase tracking-wider text-xs px-6 py-3 rounded-full transition-all shadow-[0_4px_16px_rgba(255,208,0,0.15)] active:scale-95 duration-205"
            >
              <Instagram size={14} className="text-black" />
              <span>DM "EDIT"</span>
              <ArrowUpRight size={12} className="opacity-80 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-900 focus:outline-none transition-colors"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden bg-[#050505] border-b border-white/5"
          >
            <div className="px-2 pt-2 pb-6 space-y-1 sm:px-3">
              <a
                href="#services"
                onClick={() => setIsOpen(false)}
                className="block px-3 py-3 rounded-md text-sm font-black uppercase tracking-widest text-zinc-300 hover:text-[#FFD000] hover:bg-zinc-900/50"
              >
                Services
              </a>
              <a
                href="#portfolio"
                onClick={() => setIsOpen(false)}
                className="block px-3 py-3 rounded-md text-sm font-black uppercase tracking-widest text-zinc-300 hover:text-[#FFD000] hover:bg-zinc-900/50"
              >
                Portfolio
              </a>
              <a
                href="#process"
                onClick={() => setIsOpen(false)}
                className="block px-3 py-3 rounded-md text-sm font-black uppercase tracking-widest text-zinc-300 hover:text-[#FFD000] hover:bg-zinc-900/50"
              >
                Process
              </a>
              <a
                href="#calculator"
                onClick={() => setIsOpen(false)}
                className="block px-3 py-3 rounded-md text-sm font-black uppercase tracking-widest text-zinc-300 hover:text-[#FFD000] hover:bg-zinc-900/50"
              >
                Calculator
              </a>
              <a
                href="#pricing"
                onClick={() => setIsOpen(false)}
                className="block px-3 py-3 rounded-md text-sm font-black uppercase tracking-widest text-zinc-300 hover:text-[#FFD000] hover:bg-zinc-900/50"
              >
                Packages
              </a>
              <div className="pt-4 px-3">
                <a
                  href="https://www.instagram.com/editwitharman/"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center gap-2 w-full bg-[#FFD000] text-black font-black uppercase tracking-widest text-xs py-4 rounded-full shadow-[0_4px_16px_rgba(255,208,0,0.15)]"
                >
                  <Instagram size={14} />
                  <span>DM "EDIT" on Instagram</span>
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
