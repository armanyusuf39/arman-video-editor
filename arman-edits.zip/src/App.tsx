import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Services from "./components/Services";
import Portfolio from "./components/Portfolio";
import Calculator from "./components/Calculator";
import Process from "./components/Process";
import Pricing from "./components/Pricing";
import FAQ from "./components/FAQ";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="relative min-h-screen bg-zinc-950 text-white font-sans antialiased overflow-hidden selection:bg-brand selection:text-zinc-950">
      
      {/* Dynamic Background Noise Overlay for Premium Aesthetic Texture */}
      <div className="absolute inset-0 bg-noise opacity-[0.015] pointer-events-none z-50" />
      
      {/* Main Structural Flow */}
      <Navbar />
      
      <main>
        <Hero />
        <Services />
        <Portfolio />
        <Calculator />
        <Process />
        <Pricing />
        <FAQ />
      </main>

      <Footer />
    </div>
  );
}

