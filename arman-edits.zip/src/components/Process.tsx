import { Send, Cpu, MessageSquare, ArrowUpRight } from "lucide-react";

export default function Process() {
  const steps = [
    {
      num: "01",
      title: "Send Raw Footage",
      desc: "Upload raw files via Google Drive, Dropbox, Frame.io or WeTransfer, along with any branding guidelines or script anchors.",
      icon: <Send className="text-[#FFD000]" size={20} />,
    },
    {
      num: "02",
      title: "Strategic Edit",
      desc: "I dissect the clips, isolate high-impact hooks, synchronize speed ramps, integrate cinematic captions, and master the background SFX.",
      icon: <Cpu className="text-[#FFD000]" size={20} />,
    },
    {
      num: "03",
      title: "Preview & Revise",
      desc: "Check the drafted cuts instantly via Frame.io or direct upload. Flag any required edits, caption colors, or transition speed adjustments.",
      icon: <MessageSquare className="text-[#FFD000]" size={20} />,
    },
    {
      num: "04",
      title: "Publish & Go Viral",
      desc: "Receive the high-definition ready-to-post vertical files. Seamlessly upload to Reels, TikTok, and YouTube Shorts for organic reach.",
      icon: <ArrowUpRight className="text-[#FFD000]" size={20} />,
    },
  ];

  return (
    <section id="process" className="py-20 border-t border-white/5 bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-[0.2em] text-[#FFD000]">
            <span>Workflow Engine</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl tracking-tighter text-white leading-[0.95] italic uppercase select-none">
            4 Steps to <span className="text-[#FFD000]">High Retention</span>
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed max-w-2xl pt-2">
            A frictionless handoff process designed to turn raw recorded concepts into polished visual assets with minimal effort on your part.
          </p>
        </div>

        {/* Process Steps Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 relative">
          
          {steps.map((st, i) => (
            <div
              key={st.num}
              className="group relative bg-[#111] hover:bg-[#1A1A1A] border border-white/10 rounded-[32px] p-8 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex justify-between items-center mb-6">
                  <div className="w-10 h-10 rounded-xl bg-zinc-950 border border-white/5 flex items-center justify-center">
                    {st.icon}
                  </div>
                  <span className="font-mono text-3xl font-black text-zinc-850 group-hover:text-[#FFD000]/25 transition-colors">
                    {st.num}
                  </span>
                </div>

                <h3 className="font-display font-black text-lg text-white mb-2 group-hover:text-[#FFD000] uppercase italic tracking-tight transition-colors">
                  {st.title}
                </h3>
                <p className="text-zinc-450 text-xs sm:text-sm leading-relaxed">
                  {st.desc}
                </p>
              </div>

              {/* Connecting thread helper (visual only) */}
              <div className="mt-8 text-[10px] font-mono text-zinc-550 tracking-widest uppercase">
                {i < 3 ? `PHASE ${st.num} ->` : "GO LIVE ⚡"}
              </div>
            </div>
          ))}

        </div>
      </div>
    </section>
  );
}
