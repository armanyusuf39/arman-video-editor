import { SERVICES } from "../data";
import { Video, Type, Zap, Layers, Mic, Sparkles } from "lucide-react";

export default function Services() {
  const getIcon = (name: string) => {
    switch (name) {
      case "video":
        return <Video className="text-[#FFD000]" size={24} />;
      case "text":
        return <Type className="text-[#FFD000]" size={24} />;
      case "zap":
        return <Zap className="text-[#FFD000]" size={24} />;
      case "layers":
        return <Layers className="text-[#FFD000]" size={24} />;
      case "mic":
        return <Mic className="text-[#FFD000]" size={24} />;
      case "sparkles":
        return <Sparkles className="text-[#FFD000]" size={24} />;
      default:
        return <Video className="text-[#FFD000]" size={24} />;
    }
  };

  return (
    <section id="services" className="py-20 border-t border-white/5 bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-[0.2em] text-[#FFD000]">
            <span>Services</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl tracking-tighter text-white leading-[0.95] italic uppercase select-none">
            Engineered for retention. <br />
            Built for <span className="text-[#FFD000]">Conversions</span>.
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed max-w-2xl pt-2">
            I don’t just cut clips together. I structure every hook, caption, transition, and sound element to amplify authority, spark engagement, and keep viewers locked in.
          </p>
        </div>

        {/* Bento Grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SERVICES.map((svc) => (
            <div
              key={svc.id}
              className="group relative bg-[#111] hover:bg-[#1a1a1a] border border-white/10 rounded-[32px] p-8 transition-all duration-350 overflow-hidden flex flex-col justify-between"
            >
              <div>
                {/* Header Row */}
                <div className="flex justify-between items-start mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-zinc-950 border border-white/5 flex items-center justify-center group-hover:border-[#FFD000]/30 transition-colors">
                    {getIcon(svc.iconName)}
                  </div>
                  {svc.tag && (
                    <span className="text-[10px] uppercase font-mono font-black tracking-widest px-2.5 py-1 rounded-full bg-zinc-950 text-zinc-400 border border-white/5">
                      {svc.tag}
                    </span>
                  )}
                </div>

                {/* Content */}
                <h3 className="font-display font-black italic uppercase text-lg sm:text-xl text-white mb-3 group-hover:text-[#FFD000] tracking-tight transition-colors">
                  {svc.title}
                </h3>
                <p className="text-zinc-400 text-sm leading-relaxed">
                  {svc.description}
                </p>
              </div>

              {/* Decorative design graphic in each card */}
              <div className="mt-8 flex items-center justify-between text-[10px] font-mono text-zinc-650 select-none border-t border-white/5 pt-4 group-hover:border-white/10 transition-colors">
                <span>00:60 OPTIMIZED</span>
                <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-[#FFD000] font-bold">ACTIVE SYSTEM ✦</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
