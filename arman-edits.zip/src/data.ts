import { FAQItem, ServiceItem, PortfolioItem, PackagePreset } from "./types";

export const SERVICES: ServiceItem[] = [
  {
    id: "reels-shorts",
    title: "Short-Form Mastery",
    description: "Multi-platform editing perfectly calibrated for Instagram Reels, TikTok, and YouTube Shorts. Retaining eyes on every swipe.",
    iconName: "video",
    tag: "Core Service",
  },
  {
    id: "captions",
    title: "Kinetic Caption Design",
    description: "Highly engaging, animated subtitles, customized branding, emojis, and sound-effect accents to maximize viewer watch time.",
    iconName: "text",
    tag: "High Value",
  },
  {
    id: "hooks",
    title: "First-3-Second Hooks",
    description: "Custom visual pattern-interrupts, split-frame clips, sound swooshes, and graphics to prevent viewers from scrolling past.",
    iconName: "zap",
  },
  {
    id: "broll",
    title: "Premium B-Roll & Visual Flow",
    description: "Seamless insertion of high-relative cinematic B-roll, digital zooms, visual assets, and animations for professional rhythm.",
    iconName: "layers",
  },
  {
    id: "podcasts",
    title: "Podcast Highlights Engine",
    description: "Transforming long-form webinars and interviews into bite-sized, ultra-focused nuggets optimized for viral loops.",
    iconName: "mic",
  },
  {
    id: "color-audio",
    title: "Sound Design & Color Grade",
    description: "Premium visual color correction matching your aesthetic, combined with noise cleanup, voice amplification, and background audio.",
    iconName: "sparkles",
  },
];

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: "talking-head",
    title: "High-Retention Talking Head",
    category: "Founder Brand Building",
    description: "A dynamic talking-head reel featuring bold highlight captions, custom sound accents, micro-zooms, and graphic pattern interrupts designed for high retention.",
    duration: "0:45",
    hookText: "3 SECRETS of 8-Figure Founders 🤫",
    captions: [
      { text: "Here are the", highlight: false },
      { text: "3 INSANE SECRETS", highlight: true },
      { text: "of eight-figure founders", highlight: false },
      { text: "that they will never tell you.", highlight: false },
      { text: "Secret #1:", highlight: false },
      { text: "AGGRESSIVE FOCUS", highlight: true },
      { text: "over everything else.", highlight: false }
    ],
    bgColor: "from-amber-500/20 to-zinc-950",
  },
  {
    id: "podcast-clip",
    title: "Viral Podcast Spotlight",
    category: "Creator Interviews",
    description: "Optimized split-screen formatting for dual-person talks. Features dynamic sound design, keyword motion pops, and fast timeline cuts that build conversational momentum.",
    duration: "0:58",
    hookText: "How he made $10K in 30 Days! 📈",
    captions: [
      { text: "How did he make", highlight: false },
      { text: "$10,000 IN JUST 30 DAYS?", highlight: true },
      { text: "It wasn't luck,", highlight: false },
      { text: "it was purely", highlight: false },
      { text: "SHORT-FORM ACQUISITION.", highlight: true },
      { text: "Let me explain how it works.", highlight: false }
    ],
    bgColor: "from-indigo-500/20 to-zinc-950",
  },
  {
    id: "brand-promo",
    title: "Premium Tech Showcase",
    category: "SaaS & Product Promo",
    description: "High-end product showcase employing kinetic titles, custom grid guidelines, synchronized heavy audio-beat syncing, and speed ramp transitions.",
    duration: "0:30",
    hookText: "Short-form is not optional in 2026 🚨",
    captions: [
      { text: "If you aren't posting", highlight: false },
      { text: "SHORT-FORM VIDEOS,", highlight: true },
      { text: "your brand is", highlight: false },
      { text: "COMPLETELY INVISIBLE", highlight: true },
      { text: "to 90% of your market.", highlight: false }
    ],
    bgColor: "from-emerald-500/20 to-zinc-950",
  },
];

export const PACKAGES: PackagePreset[] = [
  {
    id: "single",
    title: "Starter Test Reel",
    price: "$149",
    description: "Perfect if you want to sample my world-class editing style and verify how your audience responds to retention edits.",
    features: [
      "1 premium short-form video (up to 60s)",
      "Kinetic captions, emojis, & sound design",
      "Hook design & visual pattern interrupts",
      "1 revision round & standard 48h delivery",
      "Includes export ready for Reels/Shorts/TikTok"
    ],
    popular: false,
    ctaText: "Ask For Starter",
  },
  {
    id: "weekly",
    title: "Consistent Creator",
    price: "$999",
    description: "Our highly popular program. Perfect for founders, coaches, and creators building a magnetic weekly posting rhythm.",
    features: [
      "8 premium short-form videos per month",
      "Advanced motion captions & sound effects",
      "Cinematic B-roll lookup & vector overlays",
      "Strategic hook consulting for raw files",
      "Dedicated Slack communication thread",
      "Priority revisions & 36h turnaround time"
    ],
    popular: true,
    ctaText: "DM “EDIT”",
  },
  {
    id: "monthly",
    title: "Hyper-Growth Engine",
    price: "$1,899",
    description: "Complete hands-off short-form solution for modern businesses and creators targeting maximum organic growth.",
    features: [
      "16-20 premium short-form videos per month",
      "Full podcast-to-clips curation service",
      "Completely bespoke brand subtitle styling",
      "Deep frame animations & premium coloring",
      "Unlimited visual adjustment loops",
      "Top-tier priority Slack support",
      "Fast-track 24h delivery workflow"
    ],
    popular: false,
    ctaText: "Secure Growth Package",
  },
];

export const FAQS: FAQItem[] = [
  {
    id: "types",
    question: "What platforms do your videos support?",
    answer: "Every single edit is rendered in crisp 9:16 vertical resolution and optimized for Instagram Reels, TikTok, YouTube Shorts, and Facebook Reels. I ensure key text ranges are safe from native UI overlays of each platform.",
  },
  {
    id: "captions-style",
    question: "Can you match my specific branding or text style?",
    answer: "Yes, absolutely! I look at your font requirements, hex colors, and layout guidelines. Whether you like the aggressive, fast-paced Alex Hormozi layout, sleek neo-brutalist tech titles, or neat monochrome captions, I tailor the style to fit your personal brand perfectly.",
  },
  {
    id: "footage",
    question: "How do I send my raw files and media footage?",
    answer: "You can send raw video files, visual assets, and B-roll scripts using a cloud folder like Google Drive, Dropbox, Frame.io, or WeTransfer. All you need to do is share the link, and I will extract and organize them safely.",
  },
  {
    id: "turnaround",
    question: "What is your typical delivery and turnaround timeframe?",
    answer: "Single test files are completed in 36 to 48 hours. Ongoing retainer clients receive weekly batches depending on their packages, with high-priority edits turned around in as fast as 24 hours.",
  },
  {
    id: "revisions",
    question: "How do we handle video adjustments and revisions?",
    answer: "I use a collaborative feedback approach (e.g. Frame.io or timestamp notes). Under the consistent packages, adjustments are handled efficiently. Our primary aim is to establish a style you love within the first batch to minimize revision cycles later.",
  },
  {
    id: "recording",
    question: "Do you offer advice or strategy on what I should record?",
    answer: "Yes! For the Consistent Creator and Hyper-Growth plans, I review your topic ideas and hook structures. I share feedback on sound, camera positioning, on-screen energy, and pacing before you record, saving you valuable hours.",
  },
];
