export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  tag?: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  description: string;
  duration: string;
  hookText: string;
  captions: Array<{ text: string; highlight: boolean }>;
  bgColor: string;
}

export interface PackagePreset {
  id: string;
  title: string;
  price: string;
  description: string;
  features: string[];
  popular: boolean;
  ctaText: string;
}
