import { useState } from "react";
import { FAQS } from "../data";
import { ChevronDown, HelpCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function FAQ() {
  const [activeId, setActiveId] = useState<string | null>(FAQS[0].id);

  const toggleFAQ = (id: string) => {
    setActiveId(activeId === id ? null : id);
  };

  return (
    <section id="faq" className="py-20 border-t border-white/5 bg-[#050505]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-[0.2em] text-[#FFD000]">
            <span>Frequently Asked</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl tracking-tighter text-white leading-[0.95] italic uppercase select-none">
            Common <span className="text-[#FFD000]">Questions</span>
          </h2>
          <p className="text-zinc-400 text-xs sm:text-sm max-w-lg mx-auto">
            Everything you need to know about the onboarding process, editing mechanics, assets delivery, and revisions loop.
          </p>
        </div>

        {/* FAQs list */}
        <div className="space-y-3">
          {FAQS.map((faq) => {
            const isOpen = activeId === faq.id;
            return (
              <div
                key={faq.id}
                className={`rounded-[24px] border transition-all duration-300 overflow-hidden ${
                  isOpen
                    ? "bg-[#111] border-[#FFD000]"
                    : "bg-[#111]/40 border-white/10 hover:border-white/15"
                }`}
              >
                <button
                  onClick={() => toggleFAQ(faq.id)}
                  className="w-full flex justify-between items-center px-6 py-5 text-left text-white"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className={isOpen ? "text-[#FFD000]" : "text-zinc-500"} size={16} />
                    <span className="font-black text-xs sm:text-sm uppercase tracking-tight">{faq.question}</span>
                  </div>
                  <motion.div
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ duration: 0.2 }}
                    className="text-zinc-500"
                  >
                    <ChevronDown size={16} />
                  </motion.div>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div className="px-6 pb-6 pt-1 sm:pl-12 border-t border-white/5 text-xs text-zinc-400 leading-relaxed">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
